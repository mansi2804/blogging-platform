export const NavSections = [
  { title: "Academic Resources", url: "#" },
  { title: "Career Services", url: "#" },
  { title: "Campus", url: "#" },
  { title: "Culture", url: "#" },
  { title: "Local Community Resources", url: "#" },
  { title: "Social", url: "#" },
  { title: "Sports", url: "#" },
  { title: "Health and Wellness", url: "#" },
  { title: "Technology", url: "#" },
  { title: "Travel", url: "#" },
  { title: "Alumni", url: "#" },
];