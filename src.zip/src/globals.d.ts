declare module '*.md' 

