import React from "react";
import Blog from "./components/Blog.tsx";
import "./App.css";

const App = () => {
  return (
    <>
      <Blog />
    </>
  );
};

export default App;
